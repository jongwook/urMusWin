cloudsbackdropregion=Region('region', 'cloudsbackdropregion', UIParent);
cloudsbackdropregion:SetWidth(ScreenWidth());
cloudsbackdropregion:SetHeight(ScreenHeight());
cloudsbackdropregion:SetLayer("BACKGROUND");
cloudsbackdropregion:SetAnchor('BOTTOMLEFT',0,0); 
--cloudsbackdropregion:EnableClamping(true)
cloudsbackdropregion.texture = cloudsbackdropregion:Texture("cloud_sequencer.png");
cloudsbackdropregion.texture:SetGradientColor("TOP",255,255,255,255,255,255,255,255);
cloudsbackdropregion.texture:SetGradientColor("BOTTOM",255,255,255,255,255,255,255,255);
--cloudsbackdropregion.texture:SetBlendMode("BLEND")
cloudsbackdropregion.texture:SetTexCoord(0,0.63,0.94,0.0);
--cloudsbackdropregion:EnableInput(true);
cloudsbackdropregion:Show();


